# IEFproject
University project for the course Informatics for Economy and Finance, using NEM and Symbol technology.

A Command Line Interface with mnemonic private key generator for the Symbol Blockchain provided by NEM.
